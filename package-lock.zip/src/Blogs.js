import React from "react";
const Blogs = () => <div><h2>Blogs Page</h2></div>;
export default Blogs;

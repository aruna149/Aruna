import React from "react";

const FooterSection = () => {
  const styles = {
    wrapper: {
      backgroundColor: "#f5f5f5",
      fontFamily: "Poppins, sans-serif",
    },
    title: {
      textAlign: "center",
      fontSize: "2rem",
      fontWeight: "700",
      padding: "1rem 0",
      color: "#0c1833",
    },
    partnersRow: {
      backgroundColor: "#cbd0db",
      display: "flex",
      justifyContent: "space-around",
      alignItems: "center",
      padding: "1rem 0",
      flexWrap: "wrap",
    },
    partnerLogo: {
      height: "60px",
      objectFit: "contain",
      margin: "0.5rem",
    },
    footer: {
      display: "flex",
      justifyContent: "space-between",
      backgroundColor: "#f8f9fc",
      padding: "3rem 2rem",
      flexWrap: "wrap",
      position: "relative",
    },
    footerCol: {
      flex: "1",
      minWidth: "200px",
      marginBottom: "1rem",
    },
    logo: {
      height: "80px",
    },
    heading: {
      fontWeight: "600",
      marginBottom: "1rem",
    },
    list: {
      listStyle: "none",
      padding: "0",
    },
    listItem: {
      margin: "0.3rem 0",
      fontSize: "1rem",
    },
    text: {
      margin: "0.5rem 0",
      fontSize: "1rem",
    },
    icons: {
      marginTop: "1rem",
    },
    icon: {
      marginRight: "15px",
      fontSize: "1.2rem",
      cursor: "pointer",
    },
    whatsapp: {
      position: "absolute",
      right: "2rem",
      bottom: "2rem",
      height: "50px",
    },
  };

  return (
    <div style={styles.wrapper}>
      <h2 style={styles.title}>Associated With</h2>

      <div style={styles.partnersRow}>
        <img src="/images/boostmysites.png" alt="Boost My Sites" style={styles.partnerLogo} />
        <img src="/images/technext.png" alt="Technext Solutions" style={styles.partnerLogo} />
        <img src="/images/venteskraft.png" alt="Venteskraft" style={styles.partnerLogo} />
        <img src="/images/quantumsoft.png" alt="Quantumsoft" style={styles.partnerLogo} />
      </div>

      <div style={styles.footer}>
        <div style={styles.footerCol}>
          <img src="/images/aiwebx-logo.png" alt="AI WebX Logo" style={styles.logo} />
        </div>

        <div style={styles.footerCol}>
          <h3 style={styles.heading}>Our Services</h3>
          <ul style={styles.list}>
            <li style={styles.listItem}>Web Development</li>
            <li style={styles.listItem}>App Development</li>
            <li style={styles.listItem}>AI & ML Development</li>
            <li style={styles.listItem}>Blockchain Solutions</li>
            <li style={styles.listItem}>Cloud Computing Services</li>
            <li style={styles.listItem}>VR & AR Development</li>
          </ul>
        </div>

        <div style={styles.footerCol}>
          <h3 style={styles.heading}>Contact Info</h3>
          <p style={styles.text}><i className="fa fa-envelope"></i> Email: info@aiwebx.in</p>
          <p style={styles.text}><i className="fa fa-phone"></i> Phone: +916301350318</p>
          <p style={styles.text}>
            <i className="fa fa-map-marker"></i> Location: 10-47 Ambedkar Nagar, Jawaharnagar,<br />
            Turmalagiri, Hyderabad - 500087, Telangana, India
          </p>
          <div style={styles.icons}>
            <i className="fab fa-facebook-f" style={styles.icon}></i>
            <i className="fab fa-instagram" style={styles.icon}></i>
            <i className="fab fa-linkedin-in" style={styles.icon}></i>
            <i className="fab fa-twitter" style={styles.icon}></i>
          </div>
        </div>

        <img src="/images/whatsapp-icon.png" alt="WhatsApp" style={styles.whatsapp} />
      </div>
    </div>
  );
};

export default FooterSection;

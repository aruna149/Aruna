import React from "react";
const Contact = () => <div><h2>Contact Us Page</h2></div>;
export default Contact;

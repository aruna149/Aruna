import React from "react";

const Home = () => {
  return (
    <>
      <header className="hero">
        <div className="text">
          <span className="tag">IT Services</span>
          <h1>GenWebX - Powering the Future with Intelligent Solutions</h1>
          <p>
            Harness the full potential of Artificial Intelligence, Blockchain, and Cloud Computing to revolutionize your business processes.
          </p>
          <button>Get Started</button>
        </div>
        <div className="image">
          <img src="https://www.aiwebx.in/assets/images/robot.png" alt="Robot" />
        </div>
      </header>

      {/* Services Section */}
      <section className="services-section">
        <h3 className="section-subtitle">Our Services</h3>
        <h2 className="section-title">We Provide the Best IT Solution Services</h2>
        <p className="section-desc">
          At AI WebX, we offer a full range of advanced technology services designed to empower businesses with scalable, intelligent, and secure solutions.
        </p>

        <div className="services-grid">
          <div className="service-card">
            <img src="https://img.icons8.com/ios/100/web.png" alt="Web Development" />
            <h3>Web Development</h3>
            <p>
              Building websites using code, design, and content for user-friendly online experiences.
            </p>
            <a href="#">Know More »</a>
          </div>

          <div className="service-card">
            <img src="https://img.icons8.com/ios/100/mobile.png" alt="App Development" />
            <h3>App Development</h3>
            <p>
              Creating mobile applications using code, design, and user-centered features.
            </p>
            <a href="#">Know More »</a>
          </div>

          <div className="service-card">
            <img src="https://img.icons8.com/ios/100/artificial-intelligence.png" alt="AI & ML" />
            <h3>AI & ML Development</h3>
            <p>
              Building intelligent systems that learn from data to automate tasks and solve problems.
            </p>
            <a href="#">Know More »</a>
          </div>

          <div className="service-card">
            <img src="https://img.icons8.com/ios/100/blockchain-technology.png" alt="Blockchain" />
            <h3>Blockchain Solutions</h3>
            <p>
              Building decentralized applications using code, design, and user-friendly features.
            </p>
            <a href="#">Know More »</a>
          </div>
          
{/* Industries Section */}
<section className="industries-section">
  <h2 className="industries-title">Industries We Serve</h2>
  <p className="industries-subtitle">
    We cater to a wide range of industries, delivering tailored AI and tech solutions to meet specific needs:
  </p>

  <div className="industries-grid">
    <div className="industry-card">
      <h3>Healthcare</h3>
      <p>
        Transforming patient care and operations with AI-powered diagnostics, data analytics, and telemedicine solutions.
      </p>
    </div>
    <div className="industry-card">
      <h3>E-commerce & Retail</h3>
      <p>
        Enhancing customer experiences with personalized recommendations, inventory management, and secure online transactions.
      </p>
    </div>
    <div className="industry-card">
      <h3>Finance & Banking</h3>
      <p>
        Streamlining processes with AI, blockchain, and machine learning for fraud detection, risk assessment, and smarter investment strategies.
      </p>
    </div>
    <div className="industry-card">
      <h3>Energy</h3>
      <p>
        Optimizing energy management, forecasting, and sustainability with IoT and data-driven AI solutions.
      </p>
    </div>
    <div className="industry-card">
      <h3>Real Estate</h3>
      <p>
        Revolutionizing property management, investment decisions, and customer engagement with AI and predictive analytics.
      </p>
    </div>
    <div className="industry-card inactive">
      <h3>Manufacturing</h3>
      <p>
        Driving automation, predictive maintenance, and operational efficiency with AI, machine learning, and IoT technologies.
      </p>
    </div>
  </div>
</section>
{/* Process Section */}
<section className="process-section">
  <h3 className="section-subtitle highlight">How We Build Your Success</h3>

  <div className="process-grid">
    {[
      {
        title: "Requirements Gathering",
        desc: "We engage with stakeholders to gather comprehensive project requirements and understand their goals through collaborative discussions.",
        icon: "https://img.icons8.com/ios/100/task.png",
        step: "01",
      },
      {
        title: "Design & Planning",
        desc: "Our team crafts a user-centric design and creates a detailed project plan, outlining the architecture, timelines, and deliverables.",
        icon: "https://img.icons8.com/ios/100/blueprint.png",
        step: "02",
      },
      {
        title: "Development",
        desc: "Our skilled developers bring your vision to life, leveraging modern technologies to build a secure and scalable product that meets all specifications.",
        icon: "https://img.icons8.com/ios/100/code--v1.png",
        step: "03",
      },
      {
        title: "Testing",
        desc: "We subject your product to rigorous testing to ensure flawless performance across all devices, identifying and resolving any issues before launch.",
        icon: "https://img.icons8.com/ios/100/inspection.png",
        step: "04",
      },
      {
        title: "Support",
        desc: "Our commitment extends beyond launch, providing ongoing maintenance and support to keep your product thriving in the ever-evolving digital landscape.",
        icon: "https://img.icons8.com/ios/100/handshake.png",
        step: "05",
      },
    ].map((item, index) => (
      <div key={index} className="process-card">
        <img src={item.icon} alt={item.title} className="process-icon" />
        <h4>{item.title}</h4>
        <p>{item.desc}</p>
        <span className="step-number">{item.step}</span>
      </div>
    ))}
  </div>
</section>
{/* About Section */}
<section className="about-section">
  <div className="about-container">
    {/* Left Side */}
    <div className="about-image-wrapper">
      <img
        src="https://images.unsplash.com/photo-1590650046871-92c887180603" // Replace with your actual image URL or import
        alt="About Us"
        className="about-image"
      />
      <div className="experience-box">
        <h2>2+</h2>
        <h4>Years of Experience</h4>
        <p>The trusted choice for your software development solutions</p>
      </div>
    </div>

    {/* Right Side */}
    <div className="about-content">
      <h4 className="section-subtitle highlight">About Company</h4>
      <h2 className="about-title">
        Our Vision: Empowering Global Businesses with Intelligent Technology
      </h2>
      <p className="about-description">
        At AI WebX, we are committed to delivering innovative AI, Machine
        Learning, and Blockchain solutions that help businesses adapt and excel
        in an increasingly complex and competitive marketplace.
      </p>
      <button className="about-btn">Know More About Us</button>
    </div>
  </div>
</section>

<section className="contact-section">
      <div className="contact-left">
        <h2>Get in touch with us</h2>
        <p>
          We are always open to discuss your project, improve your online
          presence
        </p>

        <form className="contact-form">
          <label htmlFor="name">Name</label>
          <input type="text" id="name" placeholder="Full Name" />

          <label htmlFor="email">Email</label>
          <input type="email" id="email" placeholder="Email Address" />

          <label htmlFor="subject">Subject</label>
          <input type="text" id="subject" placeholder="Enter Subject" />

          <label htmlFor="message">Message</label>
          <textarea id="message" placeholder="Enter Message" rows="5"></textarea>

          <button type="submit">Submit</button>
        </form>
      </div>

      <div className="contact-right">
        <img
          src="/images/handshake.jpg"
          alt="Contact Visual"
          className="contact-image"
        />
      </div>
    </section>



        </div>
      </section>
    </>
  );
};

export default Home;

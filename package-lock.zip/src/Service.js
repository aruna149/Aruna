import React from "react";
const Services = () => <div><h2>Services Page</h2></div>;
export default Services;
